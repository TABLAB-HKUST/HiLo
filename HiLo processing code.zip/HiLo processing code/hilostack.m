%% Initial setup
clear all;close all;clc

bar = waitbar(0,'Define folders and parameters');

[fnames_uni,indir_uni] = uigetfile(...
    '*.tif',...
    'Please select All Uniform files to process',...
    'MultiSelect','on');
[fnames_spe,indir_spe] = uigetfile(...
    '*.tif',...
    'Please select All Speckle files to process',...
    'MultiSelect','on');
outdir = uigetdir('Please select output directory for HiLo images');
opts.Interpreter = 'tex';
opts.Resize = 'on';
opts.WindowStyle = 'normal';
input_parameters = ...                  
    str2double(...                      
    inputdlg(...                      
    {'Optical sectioning parameter',...
    'Low frequency scaling factor',...
    'Lateral resolution in px/\mum'},...
    'Define process parameters',...
    1,{'1','0.25','1.6'},opts));
%% Define parameters 
tic
time = {'Create filter',...
    'Pre-allocation',...
    'Reading images and median filtering',...
    'Bandpass filtering',...
    'Contrast evaluation',...
    'Filtering and scaling',...
    'Reconstruction and Saving',...
    'Total';...
    0,0,0,0,0,0,0,0};

stck_sz = numel(fnames_uni);            % Number of images
info = imfinfo([indir_spe,'\',...
    char(fnames_spe(1))]);              
res = input_parameters(3)*1e6*0.0254;   % Lateral resolution (uint: pixels per micron)
w = info.Width;                         % Image width
h = info.Height;                        % Image height
sigmaBP = w/(5*input_parameters(1));	% Band-pass filter frequency
kc = nearest(sigmaBP*0.18);             
sigmaLP = kc*2;                         % Cut-off frequency for low- and high-pass filter
lambda = nearest(w/(2*kc));             % Side length for contrast evaluation
if mod(lambda,2) == 0
    lambda = lambda+1;
else
end

nh = gpuArray(ones(lambda));            % GPU processing
h = h+2*lambda;                         % increase image size by lambda for padding
w = w+2*lambda;                         
Nk = sum(nh(:));                        
%% Creating filters, pre-allocating and reading image stacks

% Create band pass, high and low pass filters
waitbar(1/10,bar,'Creating filters')

lp = lpgauss(h,w,sigmaLP);
hp = hpgauss(h,w,sigmaLP);
bp = bpgauss(h,w,sigmaBP);
bp = bp/max(bp(:));

time{2,1} = round(toc/60,2);
tic

% Preallocate stacks
waitbar(2/10,bar,'Pre-allocating stacks')

uni = zeros(h,w,stck_sz,'single');
dif = zeros(h,w,stck_sz,'single');
weight = zeros(h,w,stck_sz,'single');

time{2,2} = round(toc/60,2);
tic

for    i=1:stck_sz
    
    % Read images into stack
    waitbar(3/10,bar,['Reading image pair ' int2str(i) ' of ' int2str(stck_sz)])
    u = padarray(gpuArray(single(imread([indir_uni,'\',char(fnames_uni(i))]))),[lambda lambda],'symmetric');
    s = padarray(gpuArray(single(imread([indir_spe,'\',char(fnames_spe(i))]))),[lambda lambda],'symmetric');
    uni(:,:,i) = gather(u);
    dif(:,:,i) = gather((s-u));
end
clear s u gauss_corr

time{2,3} = round(toc/60,2);
tic
%% Bandpass filtering difference image stack
waitbar(4/10,bar,'Bandpass filtering difference image stack')

dif_bp = real(ifft2(fft2(dif).*bp));
dif_min = min(dif_bp(:));
dif_bp = dif_bp-dif_min;

time{2,4} = round(toc/60,2);
tic
%% Contrast evaluation
waitbar(5/10,bar,'Contrast evaluation')

for k = 1:stck_sz
    waitbar(5/10,bar,['Contrast evaluation ',int2str(k),' of ',int2str(stck_sz)])
    d = gpuArray(dif_bp(:,:,k));
    mu = imfilter(d,nh,'same')/Nk;
    sq = imfilter(d.^2,nh,'same');
    sd = real(sqrt(complex((sq-Nk*mu.^2)/(Nk-1))));
    weight(:,:,k) = gather(sd./mu);
end

weight = weight-min(weight(:));
intermediate_weight = weight(lambda+1:end-lambda,lambda+1:end-lambda,:);
weight = weight/max(intermediate_weight(:));

waitbar(6/10,bar,'Weighting')

Lo = fft2(weight.*uni);
time{2,5} = round(toc/60,2);
tic
%% Filtering
waitbar(7/10,bar,'Filtering and low frequency scaling')

Hi = real(ifft2(fft2(uni).*hp));
Hi = Hi(lambda+1:end-lambda,lambda+1:end-lambda,:);
Lo = real(ifft2(Lo.*lp));
Lo = Lo(lambda+1:end-lambda,lambda+1:end-lambda,:);
%% Scaling
LoWeight = input_parameters(2);
Lo = Lo*LoWeight;
time{2,6} = round(toc/60,2);
tic
%% Reconstruction and 16bit conversion
waitbar(8/10,bar,'Reconstructing and converting to 16bit')

HiLo = Hi+Lo;
HiLo = im2uint16(HiLo/max(HiLo(:)));
HiLo = medfilt3(HiLo,[3 3 1]);
mkdir(outdir,strcat('HiLo_',int2str(input_parameters(1)),'_',num2str(LoWeight,2)));
%% Saving
for j=1:stck_sz
    waitbar(9/10,bar,['Saving ' int2str(j) ' of ' int2str(stck_sz)])
    imwrite(HiLo(:,:,j),[outdir,...
        '\HiLo_',...
        int2str(input_parameters(1)),'_',num2str(LoWeight,2),'\HiLo',int2str(j),'.tif'],...
        'Resolution',res,'Compression','none')
end

time{2,7} = round(toc/60,2);
time{2,8} = round(sum(cell2mat(time(2,1:7))),2);
waitbar(1,bar,['DONE!!! ','Total time taken: ','~',num2str(round(cell2mat(time(2,8)))),' Minutes'])